document.addEventListener('DOMContentLoaded', function () {
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---------- mobile nav toggle ----------
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // ---------- header shadow + scroll progress bar ----------
  var header = document.querySelector('.site-header');
  var progress = document.querySelector('.scroll-progress');
  function onScroll() {
    var scrollTop = window.scrollY || document.documentElement.scrollTop;
    if (header) header.classList.toggle('scrolled', scrollTop > 8);
    if (progress) {
      var docHeight = document.documentElement.scrollHeight - window.innerHeight;
      var pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
      progress.style.width = pct + '%';
    }
    if (!reduceMotion) updateParallax(scrollTop);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // ---------- parallax blobs ----------
  var blobs = document.querySelectorAll('.blob');
  function updateParallax(scrollTop) {
    blobs.forEach(function (b, i) {
      var speed = 0.08 + i * 0.05;
      b.style.transform = 'translateY(' + (scrollTop * speed) + 'px)';
    });
  }

  // ---------- reveal-on-scroll ----------
  var revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('in-view'); });
  }

  // ---------- section-spy nav highlighting (single-page anchor nav) ----------
  var navLinks = document.querySelectorAll('.main-nav a[href^="#"]');
  var spySections = [];
  navLinks.forEach(function (link) {
    var id = link.getAttribute('href').slice(1);
    var el = document.getElementById(id);
    if (el) spySections.push({ id: id, el: el, link: link });
  });
  if ('IntersectionObserver' in window && spySections.length > 1) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        var match = spySections.find(function (s) { return s.el === entry.target; });
        if (!match) return;
        if (entry.isIntersecting) {
          navLinks.forEach(function (l) { l.classList.remove('active'); });
          match.link.classList.add('active');
        }
      });
    }, { rootMargin: '-40% 0px -55% 0px', threshold: 0 });
    spySections.forEach(function (s) { spy.observe(s.el); });
  }

  // ---------- interactive checklist ----------
  document.querySelectorAll('[data-checklist]').forEach(function (list) {
    var boxes = list.querySelectorAll('input[type="checkbox"]');
    var counter = document.querySelector('[data-checklist-count="' + list.dataset.checklist + '"]');
    function update() {
      var checked = list.querySelectorAll('input[type="checkbox"]:checked').length;
      if (counter) counter.textContent = checked + ' / ' + boxes.length + ' complete';
    }
    boxes.forEach(function (b) { b.addEventListener('change', update); });
    update();
  });

  // ---------- scored quiz ----------
  document.querySelectorAll('[data-quiz]').forEach(function (quiz) {
    var form = quiz.querySelector('form');
    var result = quiz.querySelector('[data-quiz-result]');
    if (!form) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var questions = quiz.querySelectorAll('[data-answer]');
      var score = 0;
      questions.forEach(function (q) {
        var correct = q.dataset.answer;
        var picked = q.querySelector('input[type="radio"]:checked');
        var note = q.querySelector('.q-feedback');
        if (picked && picked.value === correct) {
          score++;
          if (note) { note.textContent = 'Correct.'; note.style.color = '#16A34A'; }
        } else if (note) {
          note.textContent = picked ? 'Not quite — review this topic.' : 'No answer selected.';
          note.style.color = '#FF4FA0';
        }
      });
      if (result) {
        result.hidden = false;
        result.textContent = 'Score: ' + score + ' / ' + questions.length + '. ' + (
          score === questions.length ? 'Excellent — you have a strong grasp of the fundamentals.' :
          score >= questions.length * 0.6 ? 'Good progress — revisit the highlighted sections above.' :
          'Worth a re-read of the Foundations and Methodologies sections before you start planning.'
        );
        result.setAttribute('tabindex', '-1');
        result.focus();
      }
    });
  });

  // ---------- self-assessment slider tool ----------
  var selfForm = document.querySelector('[data-selfassess]');
  if (selfForm) {
    var out = document.querySelector('[data-selfassess-result]');
    selfForm.addEventListener('input', function () {
      var sliders = selfForm.querySelectorAll('input[type="range"]');
      var total = 0, max = 0;
      sliders.forEach(function (s) { total += Number(s.value); max += Number(s.max); });
      var pct = Math.round((total / max) * 100);
      var label = pct >= 80 ? 'Strong readiness — proceed to detailed planning.' :
                  pct >= 55 ? 'Reasonable readiness — shore up the weaker dimensions first.' :
                  'Early stage — treat this as a discovery phase before committing resources.';
      if (out) out.textContent = 'Readiness score: ' + pct + '%. ' + label;
    });
  }
});
